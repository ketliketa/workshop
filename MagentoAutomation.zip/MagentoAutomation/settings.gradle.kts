rootProject.name = "MagentoAutomation"

